from django.urls import path
from django.contrib.auth import views as auth_views
from .views import *

urlpatterns = [
    path('', ProfileUpdateView.as_view(), name='account'),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('profile_activate/<uidb64>/<token>/',
         profile_activate, name='profile_activate'),
    path('profile_delete/', ProfileDeleteView.as_view(), name='profile_delete'),
    path('all_users/', AllUsersView.as_view(), name='all_users'),
    path('email_confirm_done/', email_confirm_done, name='email_confirm_done'),
]
