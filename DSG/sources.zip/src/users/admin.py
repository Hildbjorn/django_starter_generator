from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.templatetags.static import static
from django.utils.html import format_html
from .forms import ProfileCreationForm, ProfileChangeForm
from .models import Profile


@admin.register(Profile)
class ProfileAdmin(UserAdmin):
    add_form = ProfileCreationForm
    form = ProfileChangeForm
    model = Profile

    def avatar_tag(self, obj):
        if obj.avatar:
            return format_html('<img id="avatar_tag" src="{}" />', obj.avatar.url)
        else:
            default_avatar_url = static('img/elements/no_photo.webp')
            return format_html('<img id="avatar_tag" src="{}" />', default_avatar_url)

    avatar_tag.short_description = 'Аватар'

    def avatar_thumbnail(self, obj):
        if obj.avatar:
            return format_html('<img id="avatar_thumbnail" src="{}" />',
                               obj.avatar.url)
        else:
            default_avatar_url = static('img/elements/no_photo.webp')
            return format_html('<img id="avatar_thumbnail" src="{}" />',
                               default_avatar_url)
    avatar_thumbnail.short_description = 'Аватар'

    list_display = (
        'avatar_tag',
        'nic_name',
        '__str__',
        # 'position',
        # 'company',
        'email',
        'phone',
        'subscription',
        'is_staff',
        'is_active',
        'is_superuser',)
    list_display_links = ('__str__', 'nic_name', 'avatar_tag', 'email',)
    list_filter = ('email', 'is_staff', 'is_active',)
    fieldsets = (
        ('Учетная запись', {'fields': ('email', 'password', )}),
        ('Персональные данные', {
         'fields': ('avatar_thumbnail', 'avatar', 'nic_name', 'last_name', 'first_name', 'middle_name', 'phone',)}),
        # ('Место работы', {'fields': ('company', 'position',)}),
        ('Согласие на обработку персональных данных',
         {'fields': (('agreement', 'subscription'),)}),
        ('Активность', {'fields': (('date_joined', 'last_login'),)}),
        ('Группы', {'fields': ('groups',)}),
        ('Разрешения', {'fields': (('is_active', 'is_staff',
         'is_superuser'), 'user_permissions',)}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'is_staff', 'is_active')}
         ),
    )
    search_fields = (
        'nic_name',
        'last_name',
        'first_name',
        'middle_name',
        # 'company',
        'email',
        'phone',)
    ordering = ('last_name', 'first_name',
                'middle_name', 'email', 'nic_name', )
    readonly_fields = ('avatar_thumbnail',)


admin.site.site_title = 'DSG - Админ-панель'
admin.site.site_header = 'DSG - Админ-панель'
