import datetime
import os
import re

from uuid import uuid4
from django.apps import apps
from django.core.mail import send_mail
import telepot
import pytils as pytils
from PIL import Image
from slugify import slugify

from django.conf import settings

# Диапазон лет плюс-минус 100 лет от текущего года
YEARS = [(r, r) for r in range(datetime.date.today().year -
                               100, datetime.date.today().year + 101)]

# Диапазон чисел от 1 до 20
PERIOD = [(r, r) for r in range(1, 21)]


class TextUtils:
    """ Утилиты для обработки строк """

    @staticmethod
    def pluralize_russian(number=None, singular=None, dual=None, plural=None):
        """ Склоняет слова в зависимости от числительного в русском языке. """
        if number is None or number < 0:
            raise ValueError("Число должно быть положительным.")

        if number % 10 == 1 and number % 100 != 11:
            return (number, singular)
        elif 2 <= number % 10 <= 4 and (number % 100 < 10 or number % 100 >= 20):
            return (number, dual)
        else:
            return (number, plural)

    @staticmethod
    def generate_slug(instance, slug_field_name='slug'):
        """ Создает уникальный slug для объекта модели. """
        model_name = slugify(instance.__class__.__name__)
        slug = f'{model_name}-{uuid4().hex}'

        # Проверяем уникальность slug в модели
        try:
            while instance.__class__.objects.filter(**{slug_field_name: slug}).exists():
                slug = f'{model_name}-{uuid4().hex}'
        except AttributeError:
            raise ValueError(
                "Переданный объект не имеет атрибута 'objects'. Убедитесь, что это модель Django.")
        return slug


class FileUtils:
    """ Утилиты для работы с файлами """

    # @staticmethod
    # def upload_to(instance, filename):
    #     """
    #     Функция для генерации пути загрузки файла, используя slugify для имени файла.
    #     """
    #     base_path = getattr(instance, 'upload_path', 'uploads/')
    #     name, ext = os.path.splitext(filename)
    #     slugified_name = slugify(name)
    #     return os.path.join(base_path, f'{slugified_name}{ext}').lower()

    @staticmethod
    def set_correct_avatar_filename(instance, filename):
        """Создает путь к файлу пользователя, используя его email и каталог изображений. Имя файла транслитерируется."""
        value = pytils.translit.translify(u"%s" % filename)
        name, ext = os.path.splitext(value)
        name = re.sub(r"[\W]", "_", name.strip())
        file_name = '{0}{1}'.format(name, ext).lower()
        path = 'user_files/{0}/{1}/'.format(instance.email, 'avatar')
        file_path = path + file_name
        return file_path

    @staticmethod
    def resize_and_crop_image(image_path, max_size=(150, 150)):
        img = Image.open(image_path)
        width, height = img.size
        # Определите, какая сторона изображения меньше
        if width < height:
            # Установите ширину в max_size[0], сохраняя пропорции
            new_width = max_size[0]
            new_height = int((new_width / width) * height)
        else:
            # Установите высоту в max_size[1], сохраняя пропорции
            new_height = max_size[1]
            new_width = int((new_height / height) * width)
        img = img.resize((new_width, new_height), Image.LANCZOS)
        # Обрезка изображения
        left = (new_width - max_size[0]) / 2
        right = (new_width + max_size[0]) / 2
        top = (new_height - max_size[1]) / 2
        bottom = (new_height + max_size[1]) / 2
        img = img.crop((left, top, right, bottom))
        img.save(image_path)

    @staticmethod
    def remove_empty_dirs(path):
        """ Удаляет пустые папки в заданной директории """
        # Проходим по всем подкаталогам в заданном пути
        for root, dirs, files in os.walk(path, topdown=False):
            for dir in dirs:
                dir_path = os.path.join(root, dir)
                try:
                    # Если директория пуста, удаляем её
                    os.rmdir(dir_path)
                    print(f'Удалена пустая папка: {dir_path}')
                except OSError:
                    # Если не удалось удалить (например, папка не пустая), игнорируем
                    pass


class Communications:
    """Класс коммуникаций"""

    @staticmethod
    def telegram_to_team(telegram_token=settings.TELEGRAM_TOKEN,
                         users_telegram_id=settings.USERS_TELEGRAM_ID,
                         message=None):
        """Отправка сообщения в Телеграм по списку."""
        # Проверка наличия настроек
        if not telegram_token or not users_telegram_id:
            print("\nTelegram команде (настройки не заданы)")
            print("————")
            print(message)
            return
        # Отправка сообщений, если настройки заданы
        telegramBot = telepot.Bot(telegram_token)
        for user_id in users_telegram_id:
            telegramBot.sendMessage(
                user_id, message, parse_mode='html'
            )

    @staticmethod
    def email_settings_ready():
        """Проверяет, заданы ли необходимые настройки для отправки email."""
        return all([
            settings.EMAIL_HOST,
            settings.EMAIL_PORT,
            settings.EMAIL_HOST_USER,
            settings.EMAIL_HOST_PASSWORD,
            settings.DEFAULT_FROM_EMAIL
        ])

    @staticmethod
    def email_to_user(subject=None, html_message=None, email=None):
        """ Отправка письма пользователю или вывод в консоль, если настройки не указаны """
        if super().email_settings_ready():
            # Отправляем письмо, если настройки указаны
            send_mail(subject,
                      html_message,
                      settings.DEFAULT_FROM_EMAIL,
                      [email],
                      html_message=html_message)
        else:
            # Выводим сообщение в консоль, если настройки не указаны
            print("\nНастройки не заданы. Письмо пользователю:")
            print("————")
            print(f"Subject: {subject}")
            print(f"To: {email}")
            print(f"Message: {html_message}")

    @staticmethod
    def email_to_team(subject=None, html_message_to_team=None):
        """Отправка письма всем суперпользователям и пользователям со статусом staff."""
        try:
            Profile = apps.get_model('users', 'Profile')
            users = Profile.objects.filter(is_superuser=True, is_staff=True)
            recipients = [user.email for user in users if user.email]

            if recipients:
                if super().email_settings_ready():
                    send_mail(subject,
                              html_message_to_team,
                              settings.DEFAULT_FROM_EMAIL,
                              recipients,
                              html_message=html_message_to_team)
                else:
                    print("\nНастройки не заданы. Письмо команде:")
                    print("————")
                    print(f"Subject: {subject}")
                    print(f"To: {', '.join(recipients)}")
                    print(f"Message: {html_message_to_team}")
            else:
                print("В команде никого нет.")

        except LookupError:
            print("Модель 'Profile' не найдена.")
            print("В команде никого нет.")
