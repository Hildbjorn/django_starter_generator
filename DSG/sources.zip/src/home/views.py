import os
from django.conf import settings
from django.shortcuts import render
from pathlib import Path
from django.views.generic import TemplateView

__all__ = (
    'AboutPageView',
    'IndexPageView',
)


class AboutPageView(TemplateView):
    template_name = 'home/about.html'


class IndexPageView(TemplateView):
    template_name = 'home/index.html'

    def get_context_data(self, **kwargs):
        project_name = os.path.basename(os.path.dirname(
            settings.SETTINGS_MODULE.replace('.', '/')))
        context = super().get_context_data(**kwargs)
        context['project_name'] = project_name
        return context
