console.log(`
    ██████╗     ███████╗     ██████╗     Django Starter Generator -
    ██╔══██╗    ██╔════╝    ██╔════╝     приложение для автоматизации
    ██║  ██║    ███████╗    ██║  ███╗    создания, настройки и первого
    ██║  ██║    ╚════██║    ██║   ██║    запуска проектов на Django.
    ██████╔╝    ███████║    ╚██████╔╝
    ╚═════╝     ╚══════╝     ╚═════╝     Copyright (c) 2024 Artem Fomin
        `);
/*============================================*/

// Активация ссылок
document.addEventListener("DOMContentLoaded", function () {
    var currentLocation = window.location.pathname;

    // Проверяем, есть ли элементы с классом .nav-link на странице
    if ($(".navbar .nav-link").length > 0) {
        $(".navbar .nav-link").removeClass('active');
        $(".nav-link[href='" + currentLocation + "']").addClass('active');
    }
});


// Включение экрана со спинером загрузки
document.addEventListener("DOMContentLoaded", function () {
    const buttons = document.querySelectorAll(".btn_submit");
    const spinner = document.getElementById("spinner");
    const forms = document.querySelectorAll("form");

    // Скрываем спиннер и разблокируем тело документа при загрузке
    spinner.style.display = "none";
    document.body.classList.remove('lock');

    // Проверяем наличие кнопок на странице
    if (buttons.length === 0) {
        return;
    }

    buttons.forEach(button => {
        button.addEventListener("click", function (event) {
            let hasErrors = false;
            forms.forEach(form => {
                if (form.checkValidity() === false) {
                    hasErrors = true;
                    return;
                }
            });
            if (hasErrors) {
                return;
            }
            spinner.style.display = "flex";
            document.body.classList.add('lock');
        });
    });
});

// Установка высоты #header_plug равной максимальной высоте между header и nav.navbar.
document.addEventListener("DOMContentLoaded", function () {
    const navbar = document.querySelector('nav.navbar');
    const header = document.querySelector('header');
    const headerPlug = document.getElementById('header_plug');

    function setHeaderPlugHeight() {
        const navbarHeight = navbar ? navbar.offsetHeight : 0;
        const headerHeight = header ? header.offsetHeight : 0;
        const maxHeight = Math.max(navbarHeight, headerHeight);
        headerPlug.style.height = maxHeight + 'px';
    }

    // Устанавливаем высоту при загрузке страницы
    if (headerPlug) {
        setHeaderPlugHeight();
    }

    // Устанавливаем высоту при изменении размера окна
    if (headerPlug) {
        window.addEventListener('resize', setHeaderPlugHeight);
    }
});


// Загрузка Аватара
document.addEventListener('DOMContentLoaded', function () {
    // Получаем контейнер аватара по ID
    const avatarPreview = document.getElementById('avatar_preview');

    if (avatarPreview) {
        // Находим input для загрузки файла внутри контейнера
        const avatarInput = avatarPreview.querySelector('input[type="file"][name="avatar"]');
        // Находим элемент img для предпросмотра
        const img = avatarPreview.querySelector('img');

        if (avatarInput && img) {
            avatarInput.addEventListener('change', function (event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        img.src = e.target.result; // Обновляем источник изображения
                        img.style.display = 'block'; // Убеждаемся, что изображение отображается
                    }
                    reader.readAsDataURL(file); // Читаем файл как Data URL
                } else {
                    img.style.display = 'none'; // Опционально: скрыть изображение, если файл не выбран
                }
            });
        }
    }
});

// Автозаполнение поля "Организация"
document.addEventListener("DOMContentLoaded", function () {
    findCompany();
});

function findCompany() {
    let companyField = document.querySelectorAll('.company_field');

    // Проверка наличия элементов .company_field
    if (companyField.length === 0) {
        return;
    }

    $(companyField).suggestions({
        token: "96e2dc70ca88016a7ab1e758ecd29864cd1e981d",
        type: "PARTY",
        // Вызывается, когда пользователь выбирает одну из подсказок
        onchange: function (suggestion) {
        }
    });
}


// Маска ввода номера телефона
document.addEventListener("DOMContentLoaded", function () {
    const inputs = document.querySelectorAll('.tel');

    // Проверяем, есть ли элементы с классом .tel
    if (inputs.length > 0) {
        [].forEach.call(inputs, function (input) {
            let keyCode;

            function mask(event) {
                event.keyCode && (keyCode = event.keyCode);
                let pos = this.selectionStart;
                if (pos < 3) event.preventDefault();
                let matrix = "+7 (___) ___ ____",
                    i = 0,
                    def = matrix.replace(/\D/g, ""),
                    val = this.value.replace(/\D/g, ""),
                    new_value = matrix.replace(/[_\d]/g, function (a) {
                        return i < val.length ? val.charAt(i++) || def.charAt(i) : a;
                    });
                i = new_value.indexOf("_");
                if (i != -1) {
                    i < 5 && (i = 3);
                    new_value = new_value.slice(0, i);
                }
                let reg = matrix.substr(0, this.value.length).replace(/_+/g,
                    function (a) {
                        return "\\d{1," + a.length + "}";
                    }).replace(/[+()]/g, "\\$&");
                reg = new RegExp("^" + reg + "$");
                if (!reg.test(this.value) || this.value.length < 5 || keyCode > 47 && keyCode < 58) this.value = new_value;
                if (event.type == "blur" && this.value.length < 5) this.value = "";
            }

            input.addEventListener("input", mask, false);
            input.addEventListener("focus", mask, false);
            input.addEventListener("blur", mask, false);
            input.addEventListener("keydown", mask, false);
        });
    }
});
