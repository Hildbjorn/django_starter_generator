console.log(`
    ██████╗     ███████╗     ██████╗     Django Starter Generator -
    ██╔══██╗    ██╔════╝    ██╔════╝     приложение для автоматизации
    ██║  ██║    ███████╗    ██║  ███╗    создания, настройки и первого
    ██║  ██║    ╚════██║    ██║   ██║    запуска проектов на Django.
    ██████╔╝    ███████║    ╚██████╔╝
    ╚═════╝     ╚══════╝     ╚═════╝     Copyright (c) 2024 Artem Fomin
        `);
/*============================================*/

// Активация ссылок
document.addEventListener("DOMContentLoaded", function () {
    var currentLocation = window.location.pathname;

    // Проверяем, есть ли элементы с классом .nav-link на странице
    if ($(".navbar .nav-link").length > 0) {
        $(".navbar .nav-link").removeClass('active');
        $(".nav-link[href='" + currentLocation + "']").addClass('active');
    }
});


// Включение экрана со спинером загрузки
document.addEventListener("DOMContentLoaded", function () {
    const buttons = document.querySelectorAll(".btn_submit");
    const spinner = document.getElementById("spinner");
    const forms = document.querySelectorAll("form");

    // Скрываем спиннер и разблокируем тело документа при загрузке
    spinner.style.display = "none";
    document.body.classList.remove('lock');

    // Проверяем наличие кнопок на странице
    if (buttons.length === 0) {
        return;
    }

    buttons.forEach(button => {
        button.addEventListener("click", function (event) {
            let hasErrors = false;
            forms.forEach(form => {
                if (form.checkValidity() === false) {
                    hasErrors = true;
                    return;
                }
            });
            if (hasErrors) {
                return;
            }
            spinner.style.display = "flex";
            document.body.classList.add('lock');
        });
    });
});

// Подстройка высоты элемента подложки (header_plug) под высоту заголовка (header).
document.addEventListener("DOMContentLoaded", function () {
    const header = document.querySelector('header');
    const headerPlug = document.getElementById('header_plug');

    function setHeaderPlugHeight() {
        if (headerPlug) {
            const headerHeight = header ? header.offsetHeight : 0;
            headerPlug.style.height = headerHeight + 'px';
        }
    }

    // Устанавливаем высоту при загрузке страницы
    setHeaderPlugHeight();

    // Устанавливаем высоту при изменении размера окна
    window.addEventListener('resize', setHeaderPlugHeight);
});


// Загрузка Аватара
document.addEventListener("DOMContentLoaded", function () {
    if (window.location.pathname.includes('/account')) {
        const form = document.getElementById('account_form');
        const formImage = document.getElementById('avatar_field');
        const formPreview = document.getElementById('avatar_preview');

        // Проверяем наличие необходимых элементов
        if (!formImage || !formPreview) {
            return;
        }

        // Слушаем изменения в инпуте file
        formImage.addEventListener('change', () => {
            uploadFile(formImage.files[0]);
        });

        function uploadFile(file) {
            // проверяем тип файла
            if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
                alert('Разрешены только изображения в формате .jpeg, .png или .gif.');
                formImage.value = '';
                return;
            }
            // проверим размер файла (<2 Мб)
            if (file.size > 2 * 1024 * 1024) {
                alert('Файл должен быть менее 2 МБ.');
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                formPreview.innerHTML = `<img src="${e.target.result}" alt="Аватар">`;
            };
            reader.onerror = function (e) {
                alert('Ошибка при загрузке файла.');
            };
            reader.readAsDataURL(file);
        }
    }
});


// Автозаполнение поля "Организация"
document.addEventListener("DOMContentLoaded", function () {
    findCompany();
});

function findCompany() {
    let companyField = document.querySelectorAll('.company_field');

    // Проверка наличия элементов .company_field
    if (companyField.length === 0) {
        console.error('Элементы с классом .company_field не найдены.');
        return;
    }

    $(companyField).suggestions({
        token: "96e2dc70ca88016a7ab1e758ecd29864cd1e981d",
        type: "PARTY",
        // Вызывается, когда пользователь выбирает одну из подсказок
        onchange: function (suggestion) {
        }
    });
}


// Маска ввода номера телефона
document.addEventListener("DOMContentLoaded", function () {
    const inputs = document.querySelectorAll('.tel');

    // Проверяем, есть ли элементы с классом .tel
    if (inputs.length > 0) {
        [].forEach.call(inputs, function (input) {
            let keyCode;

            function mask(event) {
                event.keyCode && (keyCode = event.keyCode);
                let pos = this.selectionStart;
                if (pos < 3) event.preventDefault();
                let matrix = "+7 (___) ___ ____",
                    i = 0,
                    def = matrix.replace(/\D/g, ""),
                    val = this.value.replace(/\D/g, ""),
                    new_value = matrix.replace(/[_\d]/g, function (a) {
                        return i < val.length ? val.charAt(i++) || def.charAt(i) : a;
                    });
                i = new_value.indexOf("_");
                if (i != -1) {
                    i < 5 && (i = 3);
                    new_value = new_value.slice(0, i);
                }
                let reg = matrix.substr(0, this.value.length).replace(/_+/g,
                    function (a) {
                        return "\\d{1," + a.length + "}";
                    }).replace(/[+()]/g, "\\$&");
                reg = new RegExp("^" + reg + "$");
                if (!reg.test(this.value) || this.value.length < 5 || keyCode > 47 && keyCode < 58) this.value = new_value;
                if (event.type == "blur" && this.value.length < 5) this.value = "";
            }

            input.addEventListener("input", mask, false);
            input.addEventListener("focus", mask, false);
            input.addEventListener("blur", mask, false);
            input.addEventListener("keydown", mask, false);
        });
    }
});