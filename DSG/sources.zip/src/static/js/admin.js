console.log(`
    ██████╗     ███████╗     ██████╗     Django Starter Generator -
    ██╔══██╗    ██╔════╝    ██╔════╝     приложение для автоматизации
    ██║  ██║    ███████╗    ██║  ███╗    создания, настройки и первого
    ██║  ██║    ╚════██║    ██║   ██║    запуска проектов на Django.
    ██████╔╝    ███████║    ╚██████╔╝
    ╚═════╝     ╚══════╝     ╚═════╝     Copyright (c) 2024 Artem Fomin
        `);
/*============================================*/
// Показ аватара в админке
document.addEventListener('DOMContentLoaded', function () {
    const fieldsets = document.querySelectorAll('fieldset.module.aligned');

    fieldsets.forEach((fieldset) => {
        const avatarInput = fieldset.querySelector('input[type="file"][name="avatar"]');
        const thumbnail = fieldset.querySelector('#avatar_thumbnail');

        if (avatarInput && thumbnail) {
            avatarInput.addEventListener('change', function (event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        thumbnail.src = e.target.result;
                        thumbnail.style.display = 'block'; // Показываем изображение
                    }
                    reader.readAsDataURL(file);
                } else {
                    thumbnail.src = '';
                    thumbnail.style.display = 'none'; // Скрываем изображение, если файл не выбран
                }
            });
        }
    });
});

